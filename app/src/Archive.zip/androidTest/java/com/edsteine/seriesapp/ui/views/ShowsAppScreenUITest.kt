// File: src/androidTest/java/com/edsteine/seriesapp/ui/views/ShowsAppScreenUITest.kt

package com.edsteine.seriesapp.ui.views

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import com.edsteine.seriesapp.ui.theme.ShowsTheme
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import org.junit.Before
import org.junit.Rule
import org.junit.Test

@HiltAndroidTest
class ShowsAppScreenUITest {

    @get:Rule
    val hiltRule = HiltAndroidRule(this)

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Before
    fun setUp() {
        hiltRule.inject()
        composeTestRule.setContent {
            ShowsTheme {
                ShowsAppScreen()
            }
        }
    }

    @Test
    fun testBottomNavigationBar() {
        // Check if the bottom navigation bar is displayed
        composeTestRule.onNodeWithText("Home").assertExists()
        composeTestRule.onNodeWithText("Search").assertExists()
        composeTestRule.onNodeWithText("Favorites").assertExists()
        composeTestRule.onNodeWithText("Profile").assertExists()

        // Perform click on the Profile navigation item
        composeTestRule.onNodeWithText("Profile").performClick()

        // Verify if the Profile screen is displayed (additional assertions required)
    }
}
