package com.edsteine.seriesapp

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.assertIsDisplayed
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Instrumentation tests for ShowsTheme.
 * Updated on: 2024-10-15
 */
@RunWith(AndroidJUnit4::class)
class ShowsThemeUITest {
    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>() // Replace with your main activity

    @Test
    fun lightTheme_isDisplayedCorrectly() {
        composeTestRule.setContent {
            ShowsTheme(darkTheme = false) {
                Text("Light Theme Test")
            }
        }

        // Verify that the text is displayed in light theme
        composeTestRule.onNodeWithText("Light Theme Test").assertIsDisplayed()
    }

    @Test
    fun darkTheme_isDisplayedCorrectly() {
        composeTestRule.setContent {
            ShowsTheme(darkTheme = true) {
                Text("Dark Theme Test")
            }
        }

        // Verify that the text is displayed in dark theme
        composeTestRule.onNodeWithText("Dark Theme Test").assertIsDisplayed()
    }
}
