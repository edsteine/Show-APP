// File: CombinedSeriesAppTests.kt
// Date updated: 2024-10-15

package com.edsteine.seriesapp

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.edsteine.seriesapp.data.di.AppModule
import com.edsteine.seriesapp.data.model.ShowItem
import com.edsteine.seriesapp.data.model.ShowsList
import com.edsteine.seriesapp.data.remote.ShowsClient
import com.edsteine.seriesapp.data.repository.ShowsRepository
import com.edsteine.seriesapp.ui.*
import com.edsteine.seriesapp.ui.home.HomeScreen
import com.edsteine.seriesapp.ui.screens.FavoritesScreen
import com.edsteine.seriesapp.ui.screens.ProfileScreen
import com.edsteine.seriesapp.ui.screens.SearchScreen
import com.edsteine.seriesapp.ui.showsdetail.ShowsDetailsScreen
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import junit.framework.TestCase.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.MockitoAnnotations

/**
 * Combined tests for the Series App including navigation setup.
 * This file consolidates various UI and instrumentation tests and
 * integrates the app's navigation setup.
 *
 * Updated on: 2024-10-15
 */

@RunWith(AndroidJUnit4::class)
@HiltAndroidTest
class CombinedSeriesAppTests {

    @get:Rule
    val composeTestRule = createComposeRule()

    @get:Rule
    var hiltRule = HiltAndroidRule(this)

    @Mock
    lateinit var showsRepository: ShowsRepository

    private var clickedShow: ShowItem? = null
    private val clickListener = object : ShowsClickListener {
        override fun onShowClicked(showItem: ShowItem) {
            clickedShow = showItem
        }
    }

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        hiltRule.inject()
    }

    /**
     * Test to verify that the ShowsClient instance is provided correctly in the application context.
     */
    @Test
    fun testProvideShowsApi() {
        val appContext = InstrumentationRegistry.getInstrumentation().targetContext
        val showsClient: ShowsClient = AppModule.provideShowsApi()
        assertNotNull("ShowsClient should not be null", showsClient)
    }

    /**
     * Test to verify clicking on a ShowItem in the ShowsListScreen.
     */
    @Test
    fun testShowItemClick() {
        val showItem = ShowItem(id = 1, name = "Test Show")
        val showsList = listOf(showItem)

        composeTestRule.setContent {
            ShowsListScreen(shows = showsList, clickListener = clickListener)
        }

        composeTestRule.onNodeWithText("Test Show").performClick()
        assert(clickedShow == showItem) { "Expected show item was not clicked" }
    }

    /**
     * Test to verify that show names are displayed in the ShowsListScreen.
     */
    @Test
    fun showsList_DisplaysShowNames() {
        val showItems = listOf(
            ShowItem(id = 1, name = "Show One"),
            ShowItem(id = 2, name = "Show Two")
        )
        val showsList = ShowsList(shows = showItems.associateBy { it.id })

        composeTestRule.setContent {
            ShowsListScreen(showsList = showsList)
        }

        composeTestRule.onNodeWithText("Show One").assertIsDisplayed()
        composeTestRule.onNodeWithText("Show Two").assertIsDisplayed()
    }

    /**
     * Test to verify clicking on a show displays the correct detail view.
     */
    @Test
    fun showsList_ClicksOnShow_ShowsDetail() {
        val showItems = listOf(
            ShowItem(id = 1, name = "Show One"),
            ShowItem(id = 2, name = "Show Two")
        )
        val showsList = ShowsList(shows = showItems.associateBy { it.id })

        composeTestRule.setContent {
            ShowsListScreen(showsList = showsList)
        }

        composeTestRule.onNodeWithText("Show One").performClick()
        composeTestRule.onNodeWithText("Details for Show One").assertIsDisplayed()
    }

    /**
     * Test using Hilt for dependency injection to verify the ShowsListScreen behavior with a mocked repository.
     */
    @Test
    fun showsListScreen_displaysShowsFromRepository() {
        composeTestRule.setContent {
            ShowsListScreen(showsRepository)
        }

        composeTestRule.onNodeWithText("Expected Show Title").assertIsDisplayed()
    }
}

/**
 * Function to set up the navigation graph for the app.
 */
fun NavGraphBuilder.AppNavigation(navController: NavController) {
    composable("home") { HomeScreen(navController) }
    composable("search") { SearchScreen() }
    composable("favorites") { FavoritesScreen() }
    composable("profile") { ProfileScreen() }
    composable("ShowsDetails/{ShowsId}") { backStackEntry ->
        val ShowsId = backStackEntry.arguments?.getString("ShowsId")
        ShowsDetailsScreen(ShowsId)
    }
}
