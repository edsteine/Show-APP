// File: CombinedShowsListScreenTest.kt
// Date updated: 2024-10-15

package com.edsteine.seriesapp.ui

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import com.edsteine.seriesapp.MainActivity
import com.edsteine.seriesapp.data.model.ShowItem
import com.edsteine.seriesapp.data.model.ShowsList
import com.edsteine.seriesapp.data.repository.ShowsRepository
import com.edsteine.seriesapp.ui.home.HomeScreen
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import io.mockk.mockk
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mock
import org.mockito.MockitoAnnotations

/**
 * Combined UI tests for various screens in the Series App.
 * Includes Hilt tests for ShowsListScreen.
 *
 * Updated on: 2024-10-15
 */
@HiltAndroidTest
class CombinedShowsListScreenTest {

    @get:Rule
    var hiltRule = HiltAndroidRule(this)

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Mock
    lateinit var showsRepository: ShowsRepository

    private var clickedShow: ShowItem? = null

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        hiltRule.inject()
    }

    /**
     * Test to verify that show names are displayed in the ShowsListScreen.
     */
    @Test
    fun showsList_DisplaysShowNames() {
        val showItems = listOf(
            ShowItem(id = 1, name = "Show One", rating = null),
            ShowItem(id = 2, name = "Show Two", rating = null)
        )
        val showsList = ShowsList(shows = showItems.associateBy { it.id })

        composeTestRule.setContent {
            ShowsListScreen(showsList = showsList)
        }

        composeTestRule.onNodeWithText("Show One").assertIsDisplayed()
        composeTestRule.onNodeWithText("Show Two").assertIsDisplayed()
    }

    /**
     * Test to verify that clicking on a show displays the correct detail view.
     */
    @Test
    fun showsList_ClicksOnShow_ShowsDetail() {
        val showItems = listOf(
            ShowItem(id = 1, name = "Show One", rating = null),
            ShowItem(id = 2, name = "Show Two", rating = null)
        )
        val showsList = ShowsList(shows = showItems.associateBy { it.id })

        composeTestRule.setContent {
            ShowsListScreen(showsList = showsList)
        }

        composeTestRule.onNodeWithText("Show One").performClick()
        composeTestRule.onNodeWithText("Details for Show One").assertIsDisplayed()
    }

    /**
     * Test using Hilt for dependency injection to verify ShowsListScreen behavior with a mocked repository.
     */
    @Test
    fun showsListScreen_displaysShowsFromRepository() {
        composeTestRule.setContent {
            ShowsListScreen(showsRepository)
        }

        composeTestRule.onNodeWithText("Expected Show Title").assertIsDisplayed()
    }

    /**
     * Test to verify interaction on HomeScreen.
     */
    @Test
    fun homeScreen_ShowsClick() {
        composeTestRule.setContent {
            HomeScreen(navController = mockk(relaxed = true))
        }

        composeTestRule.onNodeWithText("Show Title").performClick()
    }

    /**
     * Test to verify HomeScreen displays shows.
     */
    @Test
    fun homeScreen_DisplaysShows() {
        val shows = listOf(
            ShowItem(id = "1", name = "Show 1", image = "url1"),
            ShowItem(id = "2", name = "Show 2", image = "url2")
        )

        composeTestRule.setContent {
            HomeScreen(navController = mockk(relaxed = true))
        }

        composeTestRule.onNodeWithText("Show 1").assertIsDisplayed()
    }

    /**
     * Test to verify ShowsItem UI component displays correctly.
     */
    @Test
    fun showsItem_DisplaysCorrectly() {
        val showItem = ShowItem(
            name = "Sample Show",
            image = ShowItem.Image(original = "https://example.com/image.jpg")
        )

        composeTestRule.setContent {
            ShowsItem(showResponse = showItem, clickListener = mockk(relaxed = true))
        }

        composeTestRule.onNodeWithContentDescription("Poster for Sample Show").assertIsDisplayed()
        composeTestRule.onNodeWithText("Sample Show").assertIsDisplayed()
    }
}
