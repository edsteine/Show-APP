package com.edsteine.seriesapp.ui.views

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.edsteine.seriesapp.MainActivity
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * SplashActivityUITest: Instrumentation tests for the SplashActivity's UI behavior.
 *
 * Updated on: 2024-10-15
 */
@RunWith(AndroidJUnit4::class)
class SplashActivityUITest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun testSplashNavigatesToMainActivity() {
        // Launch the SplashActivity
        composeTestRule.activity.setContent {
            SplashScreen()
        }

        // Wait for 2 seconds (duration of the splash screen)
        Thread.sleep(2500) // Slightly more than the delay to ensure navigation is complete

        // Verify that MainActivity is displayed after the splash screen
        // You can replace this assertion with a more specific check relevant to your MainActivity
        // For example, checking for a specific UI element in MainActivity
    }

    // Add more UI tests as necessary
}
