// File: ShowsDetailsScreenTest.kt
// Date updated: 2024-10-15

package com.edsteine.seriesapp.ui.showsdetail

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.*
import com.edsteine.seriesapp.data.model.later.ShowsDetails
import org.junit.Rule
import org.junit.Test

/**
 * UI Tests for the ShowsDetailsScreen component.
 * This file consolidates tests for various scenarios of displaying show details.
 *
 * Updated on: 2024-10-15
 */
class ShowsDetailsScreenTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    /**
     * Test to verify that the show name is displayed on the screen.
     */
    @Test
    fun showsDetailsScreen_displaysShowName() {
        val showDetails = ShowsDetails(
            description = "A great show",
            weight = 1,
            genres = listOf("Drama"),
            id = 1,
            image = null,
            language = "English",
            name = "Great Show",
            officialSite = null,
            premiered = "2024-10-15",
            rating = null,
            runtime = 45,
            status = "Running",
            summary = null,
            type = "Scripted"
        )

        composeTestRule.setContent {
            ShowsDetailsContent(showDetails)
        }

        // Assert that the show name is displayed
        composeTestRule.onNodeWithText("Great Show").assertIsDisplayed()
    }

    /**
     * Test to verify that the premiered date is displayed on the screen.
     */
    @Test
    fun showsDetailsScreen_displaysPremieredDate() {
        val showDetails = ShowsDetails(
            description = "A great show",
            weight = 1,
            genres = listOf("Drama"),
            id = 1,
            image = null,
            language = "English",
            name = "Great Show",
            officialSite = null,
            premiered = "2024-10-15",
            rating = null,
            runtime = 45,
            status = "Running",
            summary = null,
            type = "Scripted"
        )

        composeTestRule.setContent {
            ShowsDetailsContent(showDetails)
        }

        // Assert that the premiered date is displayed
        composeTestRule.onNodeWithText("Premiered: 2024-10-15").assertIsDisplayed()
    }

    /**
     * Test to verify that the show details are displayed, including name, release date, rating, and summary.
     */
    @Test
    fun showsDetailsScreen_displaysShowDetails() {
        val showDetails = ShowsDetails(
            name = "Test Show",
            premiered = "2021-01-01",
            rating = "5.0",
            summary = "A wonderful show that captivated the audience.",
            image = "https://example.com/image.jpg"
        )

        composeTestRule.setContent {
            ShowsDetailsContent(showDetails)
        }

        // Assert that all show details are displayed
        composeTestRule.onNodeWithText("Test Show").assertIsDisplayed()
        composeTestRule.onNodeWithText("Premiered: 2021-01-01").assertIsDisplayed()
        composeTestRule.onNodeWithText("Rating: 5.0").assertIsDisplayed()
        composeTestRule.onNodeWithText("A wonderful show that captivated the audience.").assertIsDisplayed()
    }

    /**
     * Test to verify that ShowsDetailsScreen handles null fields gracefully.
     */
    @Test
    fun showsDetailsScreen_handlesNullFieldsGracefully() {
        val showDetails = ShowsDetails(
            name = "Partial Show",
            premiered = null,
            rating = null,
            summary = null,
            image = null,
            language = "English",
            type = "Drama"
        )

        composeTestRule.setContent {
            ShowsDetailsContent(showDetails)
        }

        // Assert that the known fields are displayed and no crash occurs due to null fields
        composeTestRule.onNodeWithText("Partial Show").assertIsDisplayed()
        composeTestRule.onNodeWithText("Language: English").assertIsDisplayed()
        composeTestRule.onNodeWithText("Type: Drama").assertIsDisplayed()
    }
}
