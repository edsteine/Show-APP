package com.edsteine.seriesapp.data.utils

import org.junit.Assert.assertEquals
import org.junit.Test
import com.edsteine.seriesapp.data.model.ShowItem

class AppUtilsTest {

    /**
     * Test the extension function formatHourMinutes to ensure it formats
     * minutes into the correct string representation of hours and minutes.
     */
    @Test
    fun testFormatHourMinutes() {
        val minutes = 125
        val expected = "2:05:00"
        val result = minutes.formatHourMinutes()
        assertEquals(expected, result)
    }

    /**
     * Test DiffUtil's areItemsTheSame method to verify it correctly identifies
     * whether two ShowItem objects represent the same item.
     */
    @Test
    fun testDiffUtilAreItemsTheSame() {
        val item1 = ShowItem(id = 1)
        val item2 = ShowItem(id = 1)
        val item3 = ShowItem(id = 2)

        assertEquals(true, AppUtils.diffUtil.areItemsTheSame(item1, item2))
        assertEquals(false, AppUtils.diffUtil.areItemsTheSame(item1, item3))
    }

    /**
     * Test DiffUtil's areContentsTheSame method to verify it correctly compares
     * the contents of two ShowItem objects.
     */
    @Test
    fun testDiffUtilAreContentsTheSame() {
        val item1 = ShowItem(id = 1, name = "Show A")
        val item2 = ShowItem(id = 1, name = "Show A")
        val item3 = ShowItem(id = 1, name = "Show B")

        assertEquals(true, AppUtils.diffUtil.areContentsTheSame(item1, item2))
        assertEquals(false, AppUtils.diffUtil.areContentsTheSame(item1, item3))
    }
}
