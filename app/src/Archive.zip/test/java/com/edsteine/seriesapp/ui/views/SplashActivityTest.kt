package com.edsteine.seriesapp.ui.views

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.performClick
import org.junit.Rule
import org.junit.Test

/**
 * SplashActivityTest: Unit tests for the SplashActivity and its UI components.
 *
 * Updated on: 2024-10-15
 */
class SplashActivityTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun testSplashScreenShowsImage() {
        // Set the content of the SplashScreen to be tested
        composeTestRule.setContent {
            SplashScreen()
        }

        // Assert that the splash image is displayed
        composeTestRule.onNodeWithContentDescription(null)
            .assertIsDisplayed()
    }

    // Add additional tests as necessary
}
