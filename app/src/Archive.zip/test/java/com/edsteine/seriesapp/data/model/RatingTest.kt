// File: RatingTest.kt
// Date updated: 2024-10-15

package com.edsteine.seriesapp.data.model

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Unit tests for the Rating data class.
 *
 * These tests verify the functionality of the Rating class methods.
 */
class RatingTest {

    /**
     * Test the getRatingAsPercentage method.
     */
    @Test
    fun testGetRatingAsPercentage() {
        val rating = Rating(8.0)
        assertEquals(80.0, rating.getRatingAsPercentage(), 0.001)

        val nullRating = Rating(null)
        assertEquals(0.0, nullRating.getRatingAsPercentage(), 0.001)
    }

    /**
     * Test the getFormattedRating method.
     */
    @Test
    fun testGetFormattedRating() {
        val rating = Rating(7.5)
        assertEquals("7.5", rating.getFormattedRating())

        val nullRating = Rating(null)
        assertEquals("0.0", nullRating.getFormattedRating())
    }

    /**
     * Test the isGoodRating method.
     */
    @Test
    fun testIsGoodRating() {
        assertEquals(true, Rating(8.0).isGoodRating())
        assertEquals(false, Rating(6.5).isGoodRating())
        assertEquals(false, Rating(null).isGoodRating())
    }

    /**
     * Test the getRatingColor method.
     */
    @Test
    fun testGetRatingColor() {
        assertEquals(R.color.green, Rating(8.5).getRatingColor())
        assertEquals(R.color.yellow, Rating(6.0).getRatingColor())
        assertEquals(R.color.red, Rating(4.0).getRatingColor())
    }
}
