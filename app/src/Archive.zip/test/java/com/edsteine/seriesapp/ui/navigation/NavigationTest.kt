package com.edsteine.seriesapp.ui.navigation

import androidx.navigation.compose.NavHost
import androidx.navigation.testing.TestNavHostController
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import org.junit.Rule
import org.junit.Test

class NavigationTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun testNavigationToFavorites() {
        // Create a NavController
        val navController = TestNavHostController(composeTestRule.activity)

        composeTestRule.setContent {
            // Set up the NavHost with the AppNavigation
            NavHost(navController, startDestination = "home") {
                AppNavigation(navController)
            }
        }

        // Navigate to Favorites
        navController.navigate("favorites")

        // Assert that the FavoritesScreen is displayed
        composeTestRule.onNodeWithText("Favorites").assertIsDisplayed()
    }
}
