// File: CombinedShowsTests.kt

package com.edsteine.seriesapp.ui.showsdetail

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.edsteine.seriesapp.data.model.later.ShowsDetailsTest
import com.edsteine.seriesapp.data.repository.ShowsRepository
import com.edsteine.seriesapp.viewmodel.ShowsViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.setMain
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mockito.*

/**
 * Unit tests for the ShowsDetailsTest and ShowsViewModelTest classes.
 */
class CombinedShowsTests {

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    private lateinit var viewModel: ShowsViewModel
    private lateinit var repository: ShowsRepository

    @Before
    fun setUp() {
        repository = mock(ShowsRepository::class.java)
        viewModel = ShowsViewModel(repository)
        Dispatchers.setMain(StandardTestDispatcher())
    }

    @Test
    fun testGetShowsDetails() {
        val show = ShowsDetailsTest(
            description = "A great show",
            weight = 1,
            genres = listOf("Drama", "Thriller"),
            id = 1,
            image = null,
            language = "English",
            name = "Great Show",
            officialSite = null,
            premiered = "2024-10-15",
            rating = null,
            runtime = 45,
            status = "Running",
            summary = null,
            type = "Scripted"
        )

        assertEquals("Great Show (Premiered: 2024-10-15)", show.getShowsDetails())
    }

    @Test
    fun testIsCurrentlyAiring() {
        val show = ShowsDetailsTest(
            description = null,
            weight = null,
            genres = null,
            id = 1,
            image = null,
            language = null,
            name = "Great Show",
            officialSite = null,
            premiered = null,
            rating = null,
            runtime = null,
            status = "Running",
            summary = null,
            type = null
        )

        assertEquals(true, show.isCurrentlyAiring())
    }

    @Test
    fun testGetGenreNames() {
        val show = ShowsDetailsTest(
            description = null,
            weight = null,
            genres = listOf("action", "drama"),
            id = 1,
            image = null,
            language = null,
            name = "Great Show",
            officialSite = null,
            premiered = null,
            rating = null,
            runtime = null,
            status = null,
            summary = null,
            type = null
        )

        assertEquals(listOf("Action", "Drama"), show.getGenreNames())
    }

    @Test
    fun `getShowsDetails should update ui state on success`() = runBlocking {
        // Given
        val showsId = "1"
        val expectedDetails = ShowsDetailsTest(name = "Test Show", premiered = "2021-01-01", rating = "5.0", summary = "Summary")
        `when`(repository.getShowsDetails(showsId)).thenReturn(expectedDetails)

        // When
        viewModel.getShowsDetails(showsId)

        // Then
        assertEquals(ShowsViewModel.ShowsDetailsUiState.Success(expectedDetails), viewModel.showsDetailsUiState.value)
    }
}
