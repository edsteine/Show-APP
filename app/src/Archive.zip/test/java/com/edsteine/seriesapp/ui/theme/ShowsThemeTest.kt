package com.edsteine.seriesapp

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.assertIsDisplayed
import org.junit.Rule
import org.junit.Test

/**
 * Unit tests for ShowsTheme.
 * Updated on: 2024-10-15
 */
class ShowsThemeTest {
    @get:Rule
    val composeTestRule = createComposeRule()

    @Composable
    fun TestTheme(darkTheme: Boolean) {
        ShowsTheme(darkTheme = darkTheme) {
            // Example text to test the theme
            Text("Theme Test", color = MaterialTheme.colorScheme.onBackground)
        }
    }

    @Test
    fun lightTheme_isAppliedCorrectly() {
        composeTestRule.setContent {
            TestTheme(darkTheme = false)
        }

        // Verify the text color in light theme
        composeTestRule.onNodeWithText("Theme Test").assertIsDisplayed()
    }

    @Test
    fun darkTheme_isAppliedCorrectly() {
        composeTestRule.setContent {
            TestTheme(darkTheme = true)
        }

        // Verify the text color in dark theme
        composeTestRule.onNodeWithText("Theme Test").assertIsDisplayed()
    }
}
