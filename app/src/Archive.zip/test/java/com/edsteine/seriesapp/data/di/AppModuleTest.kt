// File: AppModuleTest.kt
// Date updated: 2024-10-15

package com.edsteine.seriesapp.data.di

import com.edsteine.seriesapp.data.remote.ShowsClient
import junit.framework.TestCase.assertNotNull
import org.junit.Test

/**
 * Unit test for the AppModule class.
 *
 * This test verifies that the provideShowsApi function returns a valid instance of ShowsClient.
 */
class AppModuleTest {

    /**
     * Test to verify that the ShowsClient instance is provided correctly.
     */
    @Test
    fun testProvideShowsApi() {
        // Act: Obtain an instance of ShowsClient using the AppModule
        val showsClient: ShowsClient = AppModule.provideShowsApi()

        // Assert: Verify that the provided ShowsClient instance is not null
        assertNotNull("ShowsClient should not be null", showsClient)
    }
}
