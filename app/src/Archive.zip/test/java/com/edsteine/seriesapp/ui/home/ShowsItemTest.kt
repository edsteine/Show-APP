// File: CombinedTests.kt

package com.edsteine.seriesapp

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.performClick
import com.edsteine.seriesapp.data.model.ShowItem
import com.edsteine.seriesapp.data.remote.ShowsClickListener
import com.edsteine.seriesapp.data.remote.ShowsRepository
import com.edsteine.seriesapp.viewmodel.ShowsViewModel
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.mockito.kotlin.verify

class CombinedTests {

    @get:Rule
    val composeTestRule = createComposeRule()

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    private var clickedShow: ShowItem? = null

    private val clickListener = object : ShowsClickListener {
        override fun onShowClicked(showItem: ShowItem) {
            clickedShow = showItem
        }
    }

    private val repository: ShowsRepository = mockk()

    @Test
    fun testShowsItemClick() {
        // Arrange
        val mockClickListener = mock<ShowsClickListener>()
        val showItem = ShowItem(
            id = 1,
            name = "Sample Show",
            image = ShowItem.Image(original = "https://example.com/image.jpg")
        )

        // Act
        composeTestRule.setContent {
            ShowsItem(showResponse = showItem, clickListener = mockClickListener)
        }

        // Assert
        composeTestRule.onNodeWithContentDescription("Poster for Sample Show")
            .performClick()

        // Verify that the click listener was called
        verify(mockClickListener).onShowClicked(showItem)
    }

    @Test
    fun `onShowClicked updates clickedShow`() {
        val show = ShowItem(id = 1, name = "Test Show", image = ShowItem.Image(original = ""))
        clickListener.onShowClicked(show)
        assertEquals(show, clickedShow)
    }

    @Test
    fun testFetchShowsSuccess() = runBlocking {
        // Prepare the test data
        val shows = listOf(
            ShowItem(id = "1", name = "Show 1", image = ShowItem.Image(original = "url1")),
            ShowItem(id = "2", name = "Show 2", image = ShowItem.Image(original = "url2"))
        )
        coEvery { repository.getShows() } returns shows

        val viewModel = ShowsViewModel(repository)
        viewModel.fetchShows()

        // Assert that the state is updated correctly
        assertEquals(viewModel.showsUiState.value, ShowsViewModel.ShowsUiState.Success(shows))
    }
}
