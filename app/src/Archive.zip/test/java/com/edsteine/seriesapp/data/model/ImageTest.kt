package com.edsteine.seriesapp.data.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for the Image data model.
 *
 * Date updated: 2024-10-15
 */
class ImageTest {

    @Test
    fun testGetImageUrl() {
        val image = Image(medium = "https://example.com/medium.jpg", original = "https://example.com/original.jpg")

        assertEquals("https://example.com/medium.jpg", image.getImageUrl("medium"))
        assertEquals("https://example.com/original.jpg", image.getImageUrl("original"))
        assertEquals(null, image.getImageUrl("invalid"))
    }

    @Test
    fun testAreImageUrlsValid() {
        val validImage = Image(medium = "https://example.com/medium.jpg", original = "https://example.com/original.jpg")
        val invalidImage = Image(medium = "invalid_url", original = null)

        assertTrue(validImage.areImageUrlsValid())
        assertFalse(invalidImage.areImageUrlsValid())
    }

    @Test
    fun testIsValidUrl() {
        val image = Image(medium = "https://example.com/medium.jpg", original = "https://example.com/original.jpg")
        val invalidImage = Image(medium = "invalid_url", original = "https://example.com/original.jpg")

        assertTrue(image.areImageUrlsValid())
        assertFalse(invalidImage.areImageUrlsValid())
    }
}
