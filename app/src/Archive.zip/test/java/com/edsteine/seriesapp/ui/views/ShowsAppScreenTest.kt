// File: src/test/java/com/edsteine/seriesapp/ui/views/ShowsAppScreenTest.kt

package com.edsteine.seriesapp.ui.views

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.edsteine.seriesapp.ui.theme.ShowsTheme
import org.junit.Rule
import org.junit.Test

class ShowsAppScreenTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun testNavigationToHomeScreen() {
        composeTestRule.setContent {
            ShowsTheme {
                ShowsAppScreen()
            }
        }

        // Verify if Home screen is displayed
        composeTestRule.onNodeWithText("Home").assertExists()

        // Perform click on Home navigation item
        composeTestRule.onNodeWithText("Home").performClick()
        // Add assertions to verify navigation
    }
}
