package com.edsteine.seriesapp.data.repository

import com.edsteine.seriesapp.data.model.ShowsList
import com.edsteine.seriesapp.data.model.later.ShowsDetailsTest
import com.edsteine.seriesapp.data.remote.ShowsClient
import com.edsteine.seriesapp.data.utils.Resource
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.mockito.Mockito.`when`
import org.mockito.Mockito.mock
import retrofit2.Response

class ShowsRepositoryTest {

    private val showsClient = mock(ShowsClient::class.java)
    private val repository = ShowsRepository(showsClient)

    @Test
    fun `getShows returns success when shows are retrieved`() = runBlocking {
        // Arrange
        val page = 0
        val expectedShowsList = ShowsList(/* Initialize with mock data */)
        val response: Response<ShowsList> = Response.success(expectedShowsList)

        `when`(showsClient.getShowsList(page)).thenReturn(response)

        // Act
        val result = repository.getShows(page).toList()

        // Assert
        assertTrue(result[0] is Resource.Loading)
        assertTrue(result[1] is Resource.Success)
        assertEquals(expectedShowsList, (result[1] as Resource.Success<*>).data)
    }

    @Test
    fun `getShowsDetails returns success when details are retrieved`() = runBlocking {
        // Arrange
        val showId = 82
        val expectedShowDetails = ShowsDetailsTest(/* Initialize with mock data */)
        val response: Response<ShowsDetailsTest> = Response.success(expectedShowDetails)

        `when`(showsClient.getShowDetails(showId)).thenReturn(response)

        // Act
        val result = repository.getShowsDetails(showId)

        // Assert
        assertTrue(result is Resource.Success)
        assertEquals(expectedShowDetails, (result as Resource.Success<*>).data)
    }
}
