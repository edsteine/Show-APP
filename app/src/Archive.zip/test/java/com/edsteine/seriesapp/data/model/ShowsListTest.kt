package com.edsteine.seriesapp.data.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * 15-10-2024
 * Unit tests for [ShowsList] to ensure correct functionality of methods.
 */
class ShowsListTest {

    @Test
    fun getShowById_ReturnsCorrectShow() {
        val showItem1 = ShowItem(id = 1, name = "Show One", rating = null)
        val showItem2 = ShowItem(id = 2, name = "Show Two", rating = null)
        val showsList = ShowsList(shows = mapOf(1 to showItem1, 2 to showItem2))

        // Test retrieving a show by ID
        assertEquals(showItem1, showsList.getShowById(1))
        assertEquals(showItem2, showsList.getShowById(2))
        assertNull(showsList.getShowById(3)) // Non-existent ID
    }

    @Test
    fun getShowNames_ReturnsListOfShowNames() {
        val showItem1 = ShowItem(id = 1, name = "Show One", rating = null)
        val showItem2 = ShowItem(id = 2, name = "Show Two", rating = null)
        val showsList = ShowsList(shows = mapOf(1 to showItem1, 2 to showItem2))

        // Test getting names of shows
        val expectedNames = listOf("Show One", "Show Two")
        assertEquals(expectedNames, showsList.getShowNames())
    }

    @Test
    fun getPopularShows_ReturnsShowsAboveMinRating() {
        val showItem1 = ShowItem(id = 1, name = "Show One", rating = Rating(8.5))
        val showItem2 = ShowItem(id = 2, name = "Show Two", rating = Rating(5.0))
        val showsList = ShowsList(shows = mapOf(1 to showItem1, 2 to showItem2))

        // Test getting popular shows
        val popularShows = showsList.getPopularShows(6.0)
        assertEquals(listOf(showItem1, showItem2), popularShows)

        val notPopularShows = showsList.getPopularShows(9.0)
        assertEquals(listOf(showItem1), notPopularShows)
    }
}
