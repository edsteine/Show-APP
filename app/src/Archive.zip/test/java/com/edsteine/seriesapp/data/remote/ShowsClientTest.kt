// File: ShowsDetailsTest.kt
// Date updated: 2024-10-15

package com.edsteine.seriesapp.data.model.later

import com.edsteine.seriesapp.data.model.Rating
import org.junit.Assert.*
import org.junit.Test

/**
 * Unit tests for the ShowsDetailsTest data class.
 *
 * Covers methods: getShowsDetails(), isCurrentlyAiring(), and getGenreNames().
 */
class ShowsDetailsTest {

    /**
     * Test the getShowsDetails() method for a show with all details provided.
     */
    @Test
    fun getShowsDetails_returnsCorrectFormat_whenAllDetailsProvided() {
        val showDetails = ShowsDetailsTest(
            description = "A great show",
            weight = 1,
            genres = listOf("Drama"),
            id = 1,
            image = null,
            language = "English",
            name = "Test Show",
            officialSite = "https://example.com",
            premiered = "2024-10-15",
            rating = Rating(average = 8.5),
            runtime = 60,
            status = "Running",
            summary = "A show about testing.",
            type = "Scripted"
        )

        val expected = "Test Show (Premiered: 2024-10-15)"
        assertEquals(expected, showDetails.getShowsDetails())
    }

    /**
     * Test the getShowsDetails() method for a show with null name and premiered date.
     */
    @Test
    fun getShowsDetails_returnsDefaultMessage_whenNameAndPremieredAreNull() {
        val showDetails = ShowsDetailsTest(
            description = null,
            weight = null,
            genres = null,
            id = 1,
            image = null,
            language = null,
            name = null,
            officialSite = null,
            premiered = null,
            rating = null,
            runtime = null,
            status = null,
            summary = null,
            type = null
        )

        val expected = "Unknown Show (Premiered: Unknown Date)"
        assertEquals(expected, showDetails.getShowsDetails())
    }

    /**
     * Test the isCurrentlyAiring() method for a show that is running.
     */
    @Test
    fun isCurrentlyAiring_returnsTrue_whenStatusIsRunning() {
        val showDetails = ShowsDetailsTest(
            description = null,
            weight = null,
            genres = null,
            id = 1,
            image = null,
            language = null,
            name = "Running Show",
            officialSite = null,
            premiered = null,
            rating = null,
            runtime = null,
            status = "Running",
            summary = null,
            type = null
        )

        assertTrue(showDetails.isCurrentlyAiring())
    }

    /**
     * Test the isCurrentlyAiring() method for a show that is not running.
     */
    @Test
    fun isCurrentlyAiring_returnsFalse_whenStatusIsNotRunning() {
        val showDetails = ShowsDetailsTest(
            description = null,
            weight = null,
            genres = null,
            id = 1,
            image = null,
            language = null,
            name = "Ended Show",
            officialSite = null,
            premiered = null,
            rating = null,
            runtime = null,
            status = "Ended",
            summary = null,
            type = null
        )

        assertFalse(showDetails.isCurrentlyAiring())
    }

    /**
     * Test the getGenreNames() method for a show with multiple genres.
     */
    @Test
    fun getGenreNames_returnsTitleCaseGenres_whenGenresAreProvided() {
        val showDetails = ShowsDetailsTest(
            description = null,
            weight = null,
            genres = listOf("drama", "comedy", "sci-fi"),
            id = 1,
            image = null,
            language = null,
            name = "Genre Show",
            officialSite = null,
            premiered = null,
            rating = null,
            runtime = null,
            status = null,
            summary = null,
            type = null
        )

        val expectedGenres = listOf("Drama", "Comedy", "Sci-Fi")
        assertEquals(expectedGenres, showDetails.getGenreNames())
    }

    /**
     * Test the getGenreNames() method for a show with no genres.
     */
    @Test
    fun getGenreNames_returnsEmptyList_whenGenresIsNull() {
        val showDetails = ShowsDetailsTest(
            description = null,
            weight = null,
            genres = null,
            id = 1,
            image = null,
            language = null,
            name = "No Genre Show",
            officialSite = null,
            premiered = null,
            rating = null,
            runtime = null,
            status = null,
            summary = null,
            type = null
        )

        assertTrue(showDetails.getGenreNames().isEmpty())
    }
}
