package com.edsteine.seriesapp.data.model

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * 15-10-2024
 * Unit tests for the ShowItem class.
 */
class ShowItemTest {

    @Test
    fun testGetShowsDetails() {
        val show = ShowItem(
            genres = listOf("Drama", "Comedy"),
            id = 1,
            image = null,
            language = "English",
            name = "Sample Show",
            officialSite = null,
            premiered = "2024-10-10",
            rating = null,
            runtime = 60,
            status = "Running",
            summary = "This is a sample show.",
            type = "Scripted",
            weight = 1
        )
        val expected = "Sample Show (Premiered: 2024-10-10)"
        assertEquals(expected, show.getShowsDetails())
    }

    @Test
    fun testIsCurrentlyAiring() {
        val show = ShowItem(
            genres = null,
            id = 1,
            image = null,
            language = null,
            name = null,
            officialSite = null,
            premiered = null,
            rating = null,
            runtime = null,
            status = "Running",
            summary = null,
            type = null,
            weight = null
        )
        assertEquals(true, show.isCurrentlyAiring())
    }

    @Test
    fun testGetGenreNames() {
        val show = ShowItem(
            genres = listOf("action", "drama"),
            id = 1,
            image = null,
            language = null,
            name = null,
            officialSite = null,
            premiered = null,
            rating = null,
            runtime = null,
            status = null,
            summary = null,
            type = null,
            weight = null
        )
        val expectedGenres = listOf("Action", "Drama")
        assertEquals(expectedGenres, show.getGenreNames())
    }
}
