// File: ResourceTest.kt
package com.edsteine.seriesapp.data.utils

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Unit tests for the Resource class.
 */
class ResourceTest {

    @Test
    fun `test success state`() {
        val resource = Resource.success("Data loaded successfully")
        assertEquals("Data loaded successfully", resource.data)
        assert(resource is Resource.Success)
    }

    @Test
    fun `test error state`() {
        val resource = Resource.error("An error occurred")
        assertEquals("An error occurred", resource.message)
        assert(resource is Resource.Error)
    }

    @Test
    fun `test loading state`() {
        val resource = Resource.loading("Loading data...")
        assertEquals("Loading data...", resource.data)
        assert(resource is Resource.Loading)
    }
}
