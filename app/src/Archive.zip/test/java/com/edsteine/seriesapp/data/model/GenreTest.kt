// File: GenreTest.kt
// Date updated: 2024-10-15

package com.edsteine.seriesapp.data.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for the Genre class.
 *
 * This test verifies the behavior of the Genre class methods.
 */
class GenreTest {

    /**
     * Test the getFormattedName method.
     */
    @Test
    fun testGetFormattedName() {
        val genre = Genre("action")
        assertEquals("Action", genre.getFormattedName()) // Test formatting of the genre name

        val genreNull = Genre(null)
        assertEquals("Unknown Genre", genreNull.getFormattedName()) // Test handling of null name
    }

    /**
     * Test the isValid method.
     */
    @Test
    fun testIsValid() {
        val validGenre = Genre("Comedy")
        assertTrue(validGenre.isValid()) // Test valid genre name

        val invalidGenre = Genre("")
        assertFalse(invalidGenre.isValid()) // Test empty genre name

        val genreNull = Genre(null)
        assertFalse(genreNull.isValid()) // Test null genre name
    }

    /**
     * Test the toString method.
     */
    @Test
    fun testToString() {
        val genre = Genre("Drama")
        assertEquals("Drama", genre.toString()) // Test string representation

        val genreNull = Genre(null)
        assertEquals("Unknown Genre", genreNull.toString()) // Test handling of null name
    }
}
