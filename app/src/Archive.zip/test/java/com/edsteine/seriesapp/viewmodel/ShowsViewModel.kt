package com.edsteine.seriesapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edsteine.seriesapp.data.model.later.ShowsDetailsTest
import com.edsteine.seriesapp.data.model.ShowItem
import com.edsteine.seriesapp.data.repository.ShowsRepository
import com.edsteine.seriesapp.data.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.* // Import Flow and related operators
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ShowsViewModel @Inject constructor(private val showsRepository: ShowsRepository) : ViewModel() {

    private val _showsUiState = MutableStateFlow<ShowsUiState>(ShowsUiState.Loading)
    val showsUiState: StateFlow<ShowsUiState> = _showsUiState


    init {
        fetchShows()
    }

    private val _showsDetailsUiState = MutableStateFlow<ShowsDetailsUiState>(ShowsDetailsUiState.Loading)
    val showsDetailsUiState: StateFlow<ShowsDetailsUiState> = _showsDetailsUiState


    fun getShowsDetails(showsId: Int) {
        viewModelScope.launch {
            _showsDetailsUiState.value = ShowsDetailsUiState.Loading // Set loading state
            val resource = showsRepository.getShowsDetails(showsId)
            _showsDetailsUiState.value = when (resource) {
                is Resource.Success -> ShowsDetailsUiState.Success(resource.data)
                is Resource.Error -> ShowsDetailsUiState.Error(resource.message ?: "Unknown error")
                else -> ShowsDetailsUiState.Error("An unexpected error occurred")

            }
        }
    }


    private fun fetchShows() {
        viewModelScope.launch {
            _showsUiState.value = ShowsUiState.Loading  // Set loading BEFORE network call
            showsRepository.getShows()
                .catch { e -> _showsUiState.value = ShowsUiState.Error("Network Error: ${e.message}") }
                .collect { resource ->
                    _showsUiState.value = when (resource) {
                        is Resource.Success -> ShowsUiState.Success(resource.data?.shows?.values?.toList().orEmpty()) // Fixed line
                        is Resource.Error -> ShowsUiState.Error(resource.message ?: "Unknown error")
                        else -> ShowsUiState.Error("An unexpected error occurred")
                    }
                }
        }
    }







    sealed class ShowsDetailsUiState {
        object Loading : ShowsDetailsUiState()
        data class Success(val showsDetails: ShowsDetailsTest?) : ShowsDetailsUiState()
        data class Error(val message: String) : ShowsDetailsUiState()
    }

    sealed class ShowsUiState {
        object Loading : ShowsUiState()
        data class Success(val shows: List<ShowItem>) : ShowsUiState()
        data class Error(val message: String) : ShowsUiState()
    }
}