package com.edsteine.seriesapp.data.remote

import com.edsteine.seriesapp.data.model.ShowItem

/**
 * Interface for handling show click events.
 *
 * This interface defines a contract for classes that implement
 * show click handling functionality. The implementing class will
 * provide the logic to be executed when a show item is clicked.
 */
interface ShowsClickListener {

    /**
     * Called when a show item is clicked.
     *
     * @param showItem The clicked show item represented by [ShowItem].
     */
    fun onShowClicked(showItem: ShowItem) // Renamed parameter for clarity
}
