package com.edsteine.seriesapp.data.model.later

import com.edsteine.seriesapp.data.model.Image
import com.edsteine.seriesapp.data.model.Rating

/**
 * Data class representing the details of a TV show.
 *
 * @property id The unique identifier for the show.
 * @property name The title of the show.
 * @property description A brief summary of the show.
 * @property type The type of the show (e.g., scripted).
 * @property premiered The date when the show premiered in ISO format (yyyy-MM-dd).
 * @property genres A list of genres associated with the show.
 * @property rating The average rating of the show (nullable).
 * @property language The primary language of the show.
 * @property officialSite The official website of the show (nullable).
 * @property runtime The runtime of the show in minutes (nullable).
 * @property status The current status of the show (e.g., Running, Ended) (nullable).
 * @property summary A brief summary of the show (nullable).
 * @property weight The weight or priority of the show (nullable).
 * @property image Image URLs for the Show (nullable).
 */
data class ShowsDetailsTest(
    val description: String?, // Brief summary of the show
    val weight: Int?, // Priority weight of the show (nullable)
    val genres: List<String>?, // List of genres (nullable)
    val id: Int, // Unique Show identifier
    val image: Image?, // Image URLs for the Show (nullable)
    val language: String?, // Show language (nullable)
    val name: String?, // Show name (nullable)
    val officialSite: String?, // Official website (nullable)
    val premiered: String?, // Premiere date (nullable)
    val rating: Rating?, // Rating information (nullable)
    val runtime: Int?, // Runtime in minutes (nullable)
    val status: String?, // Current status (Running, Ended) (nullable)
    val summary: String?, // Show summary (nullable)
    val type: String?, // Show type (Scripted, Reality) (nullable)


) {




    /**
     * Returns a formatted string with the Show's title and its premiere date.
     * If either value is null, it provides a default message.
     *
     * @return A string representation of the Show title and premiere date.
     */
    fun getShowsDetails(): String {
        return "${name ?: "Unknown Show"} (Premiered: ${premiered ?: "Unknown Date"})"
    }
    /**
     * Checks if the show is currently airing based on its status.
     * If status is null, it returns false.
     *
     * @return True if the show is currently airing; otherwise, false.
     */
    fun isCurrentlyAiring(): Boolean {
        return status?.equals("Running", ignoreCase = true) == true
    }

    /**
     * Returns a list of genre names associated with the show, formatted to title case.
     * If genres is null, returns an empty list.
     *
     * @return A list of genre names as strings.
     */
    fun getGenreNames(): List<String> {
        return genres?.map { genre ->
            genre.replaceFirstChar { char ->
                if (char.isLowerCase()) char.titlecase() else char.toString()
            }
        } ?: emptyList()
    }
}
