package com.edsteine.seriesapp.data.paging

import androidx.paging.PagingSource
import com.edsteine.seriesapp.data.model.ShowItem
import com.edsteine.seriesapp.data.remote.ShowsClient
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations
import retrofit2.Response

/**
 * Unit tests for the ShowsPagingSource.
 *
 * Updated on: 15-10-2024
 */
class ShowsPagingSourceTest {

    @Mock
    private lateinit var showsClient: ShowsClient

    private lateinit var showsPagingSource: ShowsPagingSource

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        showsPagingSource = ShowsPagingSource(showsClient)
    }

    @Test
    fun `load returns LoadResult Page on successful response`() = runBlocking {
        // Mocking response from ShowsClient
        val mockShows = listOf(ShowItem(1, "Show One"), ShowItem(2, "Show Two"))
        val mockResponse = Response.success(mockShows)

        Mockito.`when`(showsClient.getShowsList(1)).thenReturn(mockResponse)

        // Loading the data
        val result = showsPagingSource.load(PagingSource.LoadParams.Refresh(1, 10, false))

        // Assertions
        assert(result is PagingSource.LoadResult.Page)
        val page = result as PagingSource.LoadResult.Page
        assertEquals(2, page.data.size)
        assertEquals(mockShows[0], page.data[0])
    }

    @Test
    fun `load returns LoadResult Error on network exception`() = runBlocking {
        Mockito.`when`(showsClient.getShowsList(1)).thenThrow(IOException("Network Error"))

        // Loading the data
        val result = showsPagingSource.load(PagingSource.LoadParams.Refresh(1, 10, false))

        // Assertions
        assert(result is PagingSource.LoadResult.Error)
    }
}
